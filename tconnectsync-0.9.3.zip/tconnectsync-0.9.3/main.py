#!/usr/bin/env python3
from tconnectsync import main

if __name__ == '__main__':
    main()